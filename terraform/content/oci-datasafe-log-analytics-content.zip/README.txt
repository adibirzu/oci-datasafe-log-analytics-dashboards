Content
Sources: [com.oraclecloud.logging.custom.datasafe.audit]
Parsers: [ociDataSafeAuditJsonParser]
Fields: [Action Taken, Admin User, Application Contexts, Audit Event Time, Audit Location, Audit Policies, Audit Trail ID, Audit Type, Client Host, Client ID, Client IP, Client Program, Common User, Data Safe Activity, Data Safe Compartment ID, Data Safe Event ID, Data Safe Target ID, Data Safe Target Name, Database Type, Database Unique Name, Database User, Error Message, Event Name, Extended Event Attributes, External User ID, FGA Policy Name, OS Terminal, OS User, Object Name, Object Owner, Object Type, Operation Status, Peer Target Database Key, SQL Parameters, SQL Text, Schema Version, Sensitive Activity, Target Class, Target User, Trail Source]

Reference
Fields: [collectiontime, errcode, mbody, oper]
